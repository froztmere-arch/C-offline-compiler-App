using System.Diagnostics;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Loader;
using System.Text.Json;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.JSInterop;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
Studio.Http = new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) };
await builder.Build().RunAsync();

public static class Studio
{
    public static HttpClient Http;
    static List<MetadataReference> refs;
    static CSharpCompilation baseComp;
    static Task loading;
    static int counter;
    // Referenced so the linker/publisher always ships these framework assemblies.
    static readonly Type[] Keep = {
        typeof(Console), typeof(Enumerable), typeof(System.Text.RegularExpressions.Regex),
        typeof(System.Collections.Concurrent.ConcurrentDictionary<,>), typeof(System.Numerics.BigInteger) };
    static readonly string[] Fallback = { "System.Private.CoreLib", "System.Runtime", "System.Console", "System.Collections",
        "System.Linq", "System.Threading", "System.Threading.Tasks", "System.Text.RegularExpressions", "System.Memory",
        "System.Runtime.Numerics", "System.Collections.Concurrent", "System.Runtime.Extensions", "netstandard" };

    static async Task LoadRefs()
    {
        var names = new List<string>();
        try
        {
            using var doc = JsonDocument.Parse(await Http.GetStringAsync("_framework/blazor.boot.json"));
            foreach (var p in doc.RootElement.GetProperty("resources").GetProperty("assembly").EnumerateObject())
                if (p.Name.EndsWith(".dll") && (p.Name.StartsWith("System.") || p.Name == "mscorlib.dll" || p.Name == "netstandard.dll"))
                    names.Add(p.Name);
        }
        catch { names = Fallback.Select(x => x + ".dll").ToList(); }
        var list = new List<MetadataReference>();
        foreach (var name in names)
        {
            try { list.Add(MetadataReference.CreateFromImage(ImmutableCollectionsMarshal.AsImmutableArray(await Http.GetByteArrayAsync("_framework/" + name)))); }
            catch { }
        }
        if (list.Count == 0) throw new Exception("No framework reference assemblies could be loaded.");
        refs = list;
    }

    [JSInvokable]
    public static string Info() =>
        $"Ready · Roslyn {typeof(CSharpCompilation).Assembly.GetName().Version} · {System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription}";

    [JSInvokable]
    public static async Task Warm() { try { await (loading ??= LoadRefs()); } catch { loading = null; baseComp = null; } }

    [JSInvokable]
    public static async Task<string> Run(string source, string stdin)
    {
        var res = new Dictionary<string, object>();
        try
        {
            try { await (loading ??= LoadRefs()); } catch { loading = null; baseComp = null; throw; }
            var sw = Stopwatch.StartNew();
            var tree = CSharpSyntaxTree.ParseText(source, new CSharpParseOptions(LanguageVersion.Latest), "Program.cs");
            // One shared base compilation keeps Roslyn's reference tables warm, so later runs are much faster.
            // concurrentBuild:false is required: the WebAssembly runtime has one thread and parallel compile would deadlock.
            baseComp ??= CSharpCompilation.Create("UserApp", null, refs,
                new CSharpCompilationOptions(OutputKind.ConsoleApplication, optimizationLevel: OptimizationLevel.Release, concurrentBuild: false));
            var comp = baseComp.AddSyntaxTrees(tree);
            using var ms = new MemoryStream();
            var emit = comp.Emit(ms);
            res["diags"] = emit.Diagnostics
                .Where(d => d.Severity >= DiagnosticSeverity.Warning && d.Id != "CS1701" && d.Id != "CS1702")
                .Select(d =>
                {
                    var p = d.Location.GetLineSpan().StartLinePosition;
                    return new { line = p.Line + 1, col = p.Character + 1, sev = d.Severity == DiagnosticSeverity.Error ? "error" : "warning", code = d.Id, msg = d.GetMessage() };
                }).ToList();
            res["built"] = emit.Success;
            res["buildMs"] = sw.ElapsedMilliseconds;
            if (!emit.Success) return JsonSerializer.Serialize(res);

            var asm = new AssemblyLoadContext("run" + (++counter)).LoadFromStream(new MemoryStream(ms.ToArray()));
            var entry = asm.EntryPoint;
            var flags = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
            // Async Main: call the user's async method, not the compiler's blocking wrapper (would deadlock on one thread).
            if (entry.Name == "<Main>")
                entry = entry.DeclaringType.GetMethods(flags).FirstOrDefault(m =>
                    (m.Name == "Main" || m.Name == "<Main>$") && typeof(Task).IsAssignableFrom(m.ReturnType)) ?? entry;

            var so = new StringWriter(); var se = new StringWriter();
            var oo = Console.Out; var oe = Console.Error; var oi = Console.In;
            Console.SetOut(so); Console.SetError(se); Console.SetIn(new StringReader(stdin ?? ""));
            int? code = 0;
            sw.Restart();
            try
            {
                var args = entry.GetParameters().Length == 0 ? null : new object[] { new string[0] };
                var r = entry.Invoke(null, args);
                if (r is Task t) { await t; r = t.GetType().GetProperty("Result")?.GetValue(t); }
                if (r is int i) code = i;
            }
            catch (Exception e)
            {
                var x = e is TargetInvocationException tie && tie.InnerException != null ? tie.InnerException : e;
                se.WriteLine("Unhandled exception. " + x);
                code = null;
            }
            finally { Console.SetOut(oo); Console.SetError(oe); Console.SetIn(oi); }
            var o = so.ToString(); var er = se.ToString();
            res["stdout"] = o.Length > 200000 ? o.Substring(0, 200000) + "\n[output truncated]" : o;
            res["stderr"] = er.Length > 200000 ? er.Substring(0, 200000) + "\n[output truncated]" : er;
            res["code"] = code;
            res["runMs"] = sw.ElapsedMilliseconds;
        }
        catch (Exception ex) { res["error"] = ex.GetType().Name + ": " + ex.Message; }
        return JsonSerializer.Serialize(res);
    }
}
